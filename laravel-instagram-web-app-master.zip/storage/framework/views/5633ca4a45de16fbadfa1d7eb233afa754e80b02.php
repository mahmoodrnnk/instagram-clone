<?php $__env->startSection('content'); ?>  
<div class="album py-5 bg-light">
  <div class="container">
    <div class="row">
      <div class="col-md-6"> 
        <div class="my-3 p-3 bg-white rounded box-shadow" style="direction:  rtl;text-align:  right;">
          <h6 class="border-bottom border-gray pb-2 mb-0">طلبات المتابعة</h6>
          <?php $__currentLoopData = $follow_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="media text-muted pt-3">
            <img src="<?php echo e(asset('images/avatar/'.$request->from_user->avatar)); ?>" alt="" class="col-sm-2 mr-2 rounded" style="margin-right: -3%;width: 50px;height: 50px;">
            <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray" >
              <div class="d-flex justify-content-between align-items-center w-100">
                <strong class="text-gray-dark"><?php echo e($request->from_user->name); ?></strong>
                <form method="post" action="<?php echo e(action('FollowController@destroy', $request['id'])); ?>">
                <?php echo e(csrf_field()); ?>

                  <input type="submit" name="" class="btn btn-outline-warning" value="رفض الطلب" style="margin-right: 76%;">
                  <input name="_method" type="hidden" value="DELETE">
                </form> 
                <form method="post" action="<?php echo e(action('FollowController@update', $request['id'])); ?>">
                <?php echo e(csrf_field()); ?>

                  <input type="submit" class="btn btn-outline-success" value="قبول الطلب">
                  <input name="_method" type="hidden" value="PATCH">
                </form>
              </div>
              <span class="d-block">تاريخ الطلب <?php echo e($request["created_at"]); ?></span>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <small class="d-block text-right mt-3">
            <a href="#">جميع الطلبات</a>
          </small>
        </div>
      </div>  
      <!--
      </div>  
      <div class="row"> --> 
       <div class="col-md-6">
        <div class="my-3 p-3 bg-white rounded box-shadow" style="direction:  rtl;text-align:  right;">
          <h6 class="border-bottom border-gray pb-2 mb-0">الأصدقاء</h6>
            <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
              $user = $follower->from_user->id == auth()->user()->id ? $follower->to_user : $follower->from_user;
            ?>
          <div class="media text-muted pt-3">
            <img src="<?php echo e(asset('images/avatar/'.$user->avatar)); ?>" alt="" class="col-sm-2 mr-2 rounded" style="margin-right: -3%;width: 50px;height: 50px;">
            <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
              <div class="d-flex justify-content-between align-items-center w-100">
                <a href="<?php echo e(url('user/'.$user->id.'/posts')); ?>"><strong class="text-gray-dark"><?php echo e($user->name); ?></strong></a>
                <form method="post" action="<?php echo e(action('FollowController@destroy', $follower['id'])); ?>">
                <?php echo e(csrf_field()); ?>

                  <input type="submit" class="btn btn-outline-danger" value="<?php echo e($follower->from_user->id == auth()->user()->id ? 'إلغاء المتابعة' : 'حذفه من المتابعين'); ?>">
                  <input name="_method" type="hidden" value="DELETE">
                </form>  
              </div>
              <span class="d-block"><?php echo e($follower->from_user->id == auth()->user()->id ? 'تتابعه منذ' : 'يتابعك منذ'); ?> <?php echo e($follower["created_at"]); ?></span>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <small class="d-block text-right mt-3">
            <a href="#">جميع التحديثات</a>
          </small>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>