<?php $__env->startSection('content'); ?>
<div class="album py-5 bg-light">
  <div class="container">

    <div class="row">
      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="card mb-4 box-shadow">
          <img class="card-img-top" src="<?php echo e(asset('images/'.$post['image_path'])); ?>" alt="Card image cap" style="height: 250px">
          <div class="card-body" style="height:  116px;">
            <p class="card-text" style="text-align: right;direction:  rtl;"><?php echo e(str_limit($post['body'], 80)); ?></p>
            <br>
          </div>
          <div class="card-footer">
            <div class="d-flex justify-content-between align-items-center">
              <form action="<?php echo e(action('PostController@destroy', $post['id'])); ?>" method="post">
                <div class="btn-group">
                  <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(action('PostController@show', $post['id'])); ?>">عرض</a>
                  <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(action('PostController@edit', $post['id'])); ?>">تعديل</a>
                    <?php echo e(csrf_field()); ?>

                    <input name="_method" type="hidden" value="DELETE">
                    <button class="btn btn-sm btn-outline-secondary" >حذف</button>
                </div>
              </form>
              <small class="text-muted"><?php echo e($post['created_at']); ?></small>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php echo e(null !== $posts ? $posts->links("pagination::bootstrap-4") : ''); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>