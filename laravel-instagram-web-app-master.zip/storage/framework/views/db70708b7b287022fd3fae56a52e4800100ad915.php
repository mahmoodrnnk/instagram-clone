<?php $__env->startSection('content'); ?>  
<div class="album py-5 bg-light">
  <div class="container">
    <div class="row">
      <div class="col-md-6"> 
        <div class="my-3 p-3 bg-white rounded box-shadow" style="direction:  rtl;text-align:  right;">
          <h6 class="border-bottom border-gray pb-2 mb-0">المستخدمين</h6>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="media text-muted pt-3">
            <img src="<?php echo e(asset('images/avatar/'.$user->avatar)); ?>" alt="" class="col-sm-2 mr-2 rounded" style="margin-right: -3%;width: 50px;height: 50px;">
            <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray" >
              <div class="d-flex justify-content-between align-items-center w-100">
                <strong class="text-gray-dark"><?php echo e($user->name); ?></strong>
                  <form method="POST" action="<?php echo e(url('follow')); ?>">
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                  <?php echo e(csrf_field()); ?>

                    <input type="submit" class="btn btn-outline-success" value="إرسال الطلب">
                  </form>  
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <small class="d-block text-right mt-3">
            <a href="#">جميع المستخدمين</a>
          </small>
        </div>
      </div>  
      <!--
      </div>  
      <div class="row"> --> 
       <div class="col-md-6">
        <div class="my-3 p-3 bg-white rounded box-shadow" style="direction:  rtl;text-align:  right;">
          <h6 class="border-bottom border-gray pb-2 mb-0">الطلبات المرسلة</h6>
          <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="media text-muted pt-3">
            <img src="<?php echo e(asset('images/avatar/'.$request->to_user->avatar)); ?>" alt="" class="col-sm-2 mr-2 rounded" style="margin-right: -3%;width: 50px;height: 50px;">
            <div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray" >
              <div class="d-flex justify-content-between align-items-center w-100">
                <strong class="text-gray-dark"><?php echo e($request->to_user->name); ?></strong>
                <form method="post" action="<?php echo e(action('FollowController@destroy', $request['id'])); ?>">
                <?php echo e(csrf_field()); ?>

                  <input type="submit" name="" class="btn btn-outline-warning" value="حذف الطلب" >
                  <input name="_method" type="hidden" value="DELETE">
                </form>  
              </div>
              <span class="d-block">تم إرساله بتاريخ <?php echo e($request["created_at"]); ?></span>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <small class="d-block text-right mt-3">
            <a href="#">جميع التحديثات</a>
          </small>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>