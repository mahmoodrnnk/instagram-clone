<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main role="main">
        <section class="jumbotron text-center">
            <div class="container">
              <h1 class="jumbotron-heading"></h1>
              <p class="lead text-muted">قم بمشاركة جميع صورك وفيديوهاتك أنت وأصدقائك من خلال شبكة القلم</p>
              <p style="direction: rtl;">
                <a href="<?php echo e(url('home')); ?>" class="btn btn-<?php echo e(isset($active_home) ? $active_home : 'secondary'); ?> my-2">الرئيسية</a>
                <a href="<?php echo e(url('user/followers')); ?>" class="btn btn-<?php echo e(isset($active_follow) ? $active_follow : 'secondary'); ?> my-2">المتابعين</a>
                <a href="<?php echo e(url('users')); ?>" class="btn btn-<?php echo e(isset($active_user) ? $active_user : 'secondary'); ?> my-2">المستخدمين</a>
                <a href="<?php echo e(url('user/posts')); ?>" class="btn btn-<?php echo e(isset($active_profile) ? $active_profile : 'secondary'); ?> my-2">الملف الشخصي</a>
              </p>
            </div>
        </section>    
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
