<?php $__env->startSection('content'); ?>  
  <div class="album py-5 bg-light">
    <div class="container">
      <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card mb-4 box-shadow">
            <img class="card-img-top" src="<?php echo e(asset('images/'.$post['image_path'])); ?>" alt="Card image cap" style="height: 250px">
            <div class="card-body" >
              <p class="card-text" style="text-align: right;direction:  rtl;">
                <small>@ <?php echo e($post->user['name']); ?></small><br>
                <?php echo e($post['body']); ?>

              </p>
            </div>
            <div class="card-footer">  
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <a class="btn btn-sm btn-outline-secondary" href="<?php echo e(action('PostController@show', $post['id'])); ?>">عرض</a>
                  <a class="btn btn-sm btn-outline-secondary" href="#"><?php echo e($post['likes_count']); ?></a>
                </div>
                <small class="text-muted"><?php echo e($post['created_at']); ?></small>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php echo e(null !== $posts ? $posts->links("pagination::bootstrap-4") : ''); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>