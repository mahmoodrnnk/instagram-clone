<div dir="rtl">
    <h1>تطوير شبكة اجتماعية تشبه Instagram</h1>
    <p>الشيفرة المصدرية لتطبيق شبكة انستغرام  من دورة "تطوير تطبيقات الويب باستخدام PHP" المقدمة من أكاديمية حسوب</p>

<a href="https://academy.hsoub.com/learn/php-web-application-development/">دورة تطوير تطبيقات الويب باستخدام  PHP</a>
</div>